//
//  ViewController.swift
//  GlobalLatestInfoLaunchScreens
//
//  Created by SevenJustin on 2020/11/25.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

