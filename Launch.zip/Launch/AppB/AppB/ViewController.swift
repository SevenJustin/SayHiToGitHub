//
//  ViewController.swift
//  AppB
//
//  Created by SevenJustin on 2020/11/26.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func launchGlobalFromB(_ sender: Any) {
        
        let aScheme = URL(string: "launchFromB://")
        if let scheme = aScheme, UIApplication.shared.canOpenURL(scheme) {
            UIApplication.shared.open(scheme, options: [:], completionHandler: nil)
        }
    }
    
}

