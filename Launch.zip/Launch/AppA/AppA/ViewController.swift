//
//  ViewController.swift
//  AppA
//
//  Created by SevenJustin on 2020/11/26.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func launchGlobalFromA(_ sender: Any) {
        let aScheme = URL(string: "launchFromA://")
        if let scheme = aScheme, UIApplication.shared.canOpenURL(scheme) {
            UIApplication.shared.open(scheme, options: [:], completionHandler: nil)
        }
    }
    
}

